package com.zd.store;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public class MainActivity extends Activity {
    static final String PREF = "store";
    /** TODO: 改成你自己的服务器地址，例如 http://192.168.1.10:8080 （不要以 / 结尾） */
    static final String BASE = "http://10.0.2.2:8080";

    static final ExecutorService IO = Executors.newCachedThreadPool();
    static String token = "", username = "", role = "";

    EditText input;
    TextView status;
    ProgressBar bar;
    LinearLayout list;
    ProgressDialog prog;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        token = sp.getString("token", ""); username = sp.getString("username", ""); role = sp.getString("role", "");

        FrameLayout root = new FrameLayout(this);
        root.setPadding(dp(16), dp(24), dp(16), dp(16));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("小栈应用商店"); title.setTextSize(22); title.setTypeface(Typeface.DEFAULT_BOLD);

        input = new EditText(this); input.setHint("搜索软件名…");
        input.setSingleLine(); input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setOnEditorActionListener((tv, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEARCH || id == EditorInfo.IME_NULL) { doSearch(tv.getText().toString()); return true; }
            return false;
        });

        Button search = btn("搜索", v -> doSearch(input.getText().toString()));
        Button cats = btn("分类", v -> showCats());
        Button rank = btn("排行榜", v -> showRank());
        Button mine = btn("我的", v -> showMine());
        Button up = btn("＋ 上传", v -> requireLogin(this::pickApk));
        Button login = btn("登录", v -> loginDialog(null));

        status = new TextView(this); status.setPadding(0, dp(8), 0, dp(8));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true); bar.setVisibility(View.GONE);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sc = new ScrollView(this); sc.addView(list);

        LinearLayout row1 = row(search, cats, rank);
        LinearLayout row2 = row(mine, up, login);
        col.addView(title); col.addView(input); col.addView(row1); col.addView(row2);
        col.addView(status); col.addView(bar);
        col.addView(sc, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(col);
        setContentView(root);
        refreshStatus();
        if (BASE.contains("10.0.2.2")) status.append("\n提醒：请先把 BASE 改成服务器真实地址");
        else showRank();
    }

    LinearLayout row(View... vs) {
        LinearLayout r = new LinearLayout(this);
        for (View v : vs) r.addView(v);
        return r;
    }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this); b.setText(t); b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        b.setLayoutParams(p);
        return b;
    }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    void refreshStatus() {
        status.setText(token.isEmpty() ? "未登录（可浏览，上传需登录）" : "已登录: " + username + (admin() ? "（管理员）" : ""));
    }

    boolean admin() { return "admin".equals(role); }

    void toast(final String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    void busy(boolean on) { bar.setVisibility(on ? View.VISIBLE : View.GONE); }

    void loginDialog(final Runnable after) {
        LinearLayout f = new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(10), dp(20), dp(10));
        final EditText u = new EditText(this); u.setHint("用户名");
        final EditText p = new EditText(this); p.setHint("密码");
        p.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        final EditText reg = new EditText(this); reg.setText("0"); reg.setHint("1=注册新账号，0=登录");
        f.addView(u); f.addView(p); f.addView(reg);
        new AlertDialog.Builder(this).setTitle("登录 / 注册").setView(f)
                .setPositiveButton("确定", (d, i) -> IO.execute(() -> {
                    try {
                        String path = "1".equals(reg.getText().toString().trim()) ? "/api/auth/register" : "/api/auth/login";
                        JSONObject o = http("POST", path, new JSONObject()
                                .put("username", u.getText().toString().trim()).put("password", p.getText().toString()).toString());
                        token = o.optString("token", "");
                        JSONObject ou = o.optJSONObject("user");
                        if (ou != null) { username = ou.optString("username", username); role = ou.optString("role", role); }
                        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                                .putString("token", token).putString("username", username).putString("role", role).apply();
                        runOnUiThread(() -> { refreshStatus(); if (after != null) after.run(); });
                        toast("登录成功");
                    } catch (Exception e) { toast("失败: " + e.getMessage()); }
                })).setNegativeButton("取消", null).show();
    }

    void requireLogin(Runnable r) {
        if (!token.isEmpty()) { r.run(); return; }
        loginDialog(r);
    }

    void doSearch(final String kw) {
        IO.execute(() -> {
            try { render(http("GET", "/api/apps?pageSize=30&keyword=" + Uri.encode(kw == null ? "" : kw), null)); }
            catch (Exception e) { toast(e.getMessage()); }
        });
    }

    void showCats() {
        IO.execute(() -> {
            try {
                JSONObject o = http("GET", "/api/categories", null);
                JSONArray a = arr(o);
                final List<String> names = new ArrayList<>();
                for (int i = 0; i < a.length(); i++) names.add(a.getJSONObject(i).optString("name"));
                runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("分类")
                        .setItems(names.toArray(new String[0]), (d, i) -> IO.execute(() -> {
                            try { render(http("GET", "/api/apps?pageSize=30&category=" + Uri.encode(names.get(i)), null)); }
                            catch (Exception e) { toast(e.getMessage()); }
                        })).show());
            } catch (Exception e) { toast(e.getMessage()); }
        });
    }

    void showRank() {
        IO.execute(() -> {
            try { render(http("GET", "/api/apps/ranking?pageSize=30", null)); }
            catch (Exception e) { toast(e.getMessage()); }
        });
    }

    void showMine() {
        requireLogin(() -> IO.execute(() -> {
            try { render(http("GET", "/api/me/apps?pageSize=50", null)); }
            catch (Exception e) { toast(e.getMessage()); }
        }));
    }

    JSONArray arr(JSONObject o) {
        JSONArray a = o.optJSONArray("items");
        if (a != null) return a;
        Object d = o.opt("data");
        return d instanceof JSONArray ? (JSONArray) d : new JSONArray();
    }

    void render(final JSONObject page) {
        runOnUiThread(() -> {
            try {
                list.removeAllViews();
                JSONArray a = arr(page);
                if (a.length() == 0) { list.addView(tv("没有结果")); return; }
                for (int i = 0; i < a.length(); i++) {
                    final JSONObject app = a.getJSONObject(i);
                    TextView t = new TextView(this);
                    t.setText(app.optString("name", "") + "  v" + app.optString("version_name", app.optString("version", "-"))
                            + "  ↓" + app.optInt("downloads", 0) + "  ★" + app.optDouble("rating", 0)
                            + "\n" + app.optString("description", "") + "\n状态: " + statusText(app.optString("status", "")));
                    t.setTextSize(15); t.setPadding(0, dp(8), 0, dp(8));
                    t.setOnClickListener(v -> showApp(app));
                    list.addView(t);
                }
            } catch (Exception e) { toast(e.getMessage()); }
        });
    }

    String statusText(String s) {
        switch (s) {
            case "online": return "已上架";
            case "pending": return "审核中";
            case "rejected": return "已驳回";
            case "offline": return "已下架";
            case "uploading": return "上传中";
            default: return s;
        }
    }

    TextView tv(String s) { TextView t = new TextView(this); t.setText(s); t.setPadding(0, dp(8), 0, dp(8)); return t; }

    void showApp(final JSONObject app) {
        String msg = app.optString("description", "")
                + "\n版本: " + app.optString("version_name", "-")
                + "\n大小: " + (app.optLong("file_size", 0) / 1048576.0) + " MB"
                + "\n下载: " + app.optInt("downloads", 0)
                + "\n状态: " + statusText(app.optString("status", ""));
        if (admin() && "pending".equals(app.optString("status", ""))) {
            new AlertDialog.Builder(this).setTitle(app.optString("name")).setMessage(msg)
                    .setPositiveButton("通过上架", (d, i) -> review(app, true))
                    .setNeutralButton("驳回", (d, i) -> review(app, false))
                    .setNegativeButton("下载", (d, i) -> download(app)).show();
        } else {
            new AlertDialog.Builder(this).setTitle(app.optString("name")).setMessage(msg)
                    .setPositiveButton("下载安装", (d, i) -> download(app))
                    .setNegativeButton("关闭", null).show();
        }
    }

    void review(final JSONObject app, final boolean pass) {
        IO.execute(() -> {
            try {
                http("POST", "/api/admin/apps/" + app.optLong("id") + "/review?action=" + (pass ? "approve" : "reject")
                        + "&reason=", null);
                toast(pass ? "已通过" : "已驳回");
                showMine2();
            } catch (Exception e) { toast(e.getMessage()); }
        });
    }

    void showMine2() { showMine(); }

    void download(final JSONObject app) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        final long id = app.optLong("id");
        IO.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(BASE + "/api/apps/" + id + "/download").openConnection();
                c.setConnectTimeout(15000); c.setReadTimeout(0);
                if (!token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
                if (c.getResponseCode() != 200) throw new Exception("下载失败 HTTP " + c.getResponseCode());
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) dir = getFilesDir();
                final File out = new File(dir, id + "_" + safe(app.optString("name", "app")) + ".apk");
                final long total = c.getContentLengthLong();
                IO.execute(() -> {
                    try (InputStream in = c.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) {
                        byte[] buf = new byte[1 << 16]; long done = 0; int n;
                        while ((n = in.read(buf)) > 0) {
                            fo.write(buf, 0, n); done += n;
                            final long dn = done;
                            runOnUiThread(() -> {
                                if (prog != null) {
                                    prog.setMax(total > 0 ? (int) (total / 1024) : 100);
                                    prog.setProgress((int) (total > 0 ? dn / 1024 : dn / 65536));
                                }
                            });
                        }
                    } catch (Exception e) { toast("下载失败: " + e.getMessage()); return; }
                    final File f = out;
                    runOnUiThread(() -> { if (prog != null) prog.dismiss(); install(f); });
                });
                runOnUiThread(() -> {
                    prog = new ProgressDialog(MainActivity.this);
                    prog.setTitle("下载 " + app.optString("name"));
                    prog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                    prog.setCancelable(false);
                    prog.setButton(ProgressDialog.BUTTON_NEGATIVE, "取消", (d, i) -> { try { c.disconnect(); } catch (Exception ignored) {} });
                    prog.show();
                });
            } catch (Exception e) { toast(e.getMessage()); }
        });
    }

    void install(File f) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            toast("请先在设置中允许安装未知来源应用");
            return;
        }
        Uri uri;
        if (Build.VERSION.SDK_INT >= 24) {
            uri = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
        } else uri = Uri.fromFile(f);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception e) { toast("无法调起安装: " + e.getMessage()); }
    }

    void pickApk() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(i, 1); } catch (Exception e) { toast("无法打开文件选择器"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 1 && res == RESULT_OK && data != null && data.getData() != null) uploadDialog(data.getData());
    }

    void uploadDialog(final Uri uri) {
        LinearLayout f = new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(10), dp(20), dp(10));
        final EditText n = new EditText(this); final EditText v = new EditText(this); final EditText d = new EditText(this);
        n.setHint("软件名称"); v.setHint("版本号 如 1.0.0"); d.setHint("简介");
        String fn = "app.apk";
        try (Cursor cu = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cu != null && cu.moveToFirst() && cu.getString(0) != null) fn = cu.getString(0);
        } catch (Exception ignored) {}
        final String fileName = fn;
        try { n.setText(getPackageManager().getPackageArchiveInfo(getContentResolver().openFileDescriptor(uri, "r").getFileDescriptor(), 0).packageName); } catch (Exception ignored) {}
        f.addView(n); f.addView(v); f.addView(d);
        new AlertDialog.Builder(this).setTitle("上传（需管理员审核）").setView(f)
                .setPositiveButton("上传", (diag, i) -> {
                    if (n.getText().toString().trim().isEmpty()) { toast("请填名称"); return; }
                    doUpload(uri, fileName, n.getText().toString().trim(),
                            v.getText().toString().trim().isEmpty() ? "1.0.0" : v.getText().toString().trim(),
                            d.getText().toString().trim());
                }).show();
    }

    void doUpload(final Uri uri, final String fileName, final String name, final String ver, final String desc) {
        prog = new ProgressDialog(this);
        prog.setTitle("上传中"); prog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); prog.setCancelable(false);
        prog.setButton(ProgressDialog.BUTTON_NEGATIVE, "取消", (d, i) -> {});
        prog.show();
        IO.execute(() -> {
            try {
                long size = 0;
                try (Cursor cu = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
                    if (cu != null && cu.moveToFirst()) size = cu.getLong(0);
                }
                if (size <= 0) throw new Exception("无法读取文件大小");
                byte[] head = new byte[2];
                try (InputStream in = getContentResolver().openInputStream(uri)) { if (in.read(head) < 2) throw new Exception("文件为空"); }
                if (fileName.toLowerCase().endsWith(".apk") && (head[0] != 'P' || head[1] != 'K')) throw new Exception("不是有效的 APK 文件");
                final StringBuilder hash = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    byte[] buf = new byte[1 << 16]; int r;
                    while ((r = in.read(buf)) > 0) md.update(buf, 0, r);
                    for (byte x : md.digest()) hash.append(String.format("%02x", x));
                }
                final long totalSize = size;
                runOnUiThread(() -> prog.setMax(100));
                JSONObject init = http("POST", "/api/apps/upload/init", new JSONObject()
                        .put("name", name).put("version_name", ver).put("file_name", fileName)
                        .put("file_size", size).put("sha256", hash.toString()).toString());
                final long id = init.getLong("uploadId");
                final int chunkSize = init.optInt("chunkSize", 1 << 20);
                runOnUiThread(() -> prog.setMax((int) (totalSize / 1024) + 1));
                int idx = 0;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    byte[] buf = new byte[chunkSize]; int r;
                    while ((r = in.read(buf)) > 0) {
                        byte[] part = Arrays.copyOf(buf, r);
                        final int pct = (int) (idx * chunkSize * 100 / totalSize);
                        runOnUiThread(() -> { if (prog != null) prog.setProgress(Math.min(99, pct)); });
                        if (httpMultipart("/api/apps/upload/chunk?idx=" + idx, "file", fileName, part,
                                "upload_id", String.valueOf(id), "index", String.valueOf(idx)) == null) break;
                        idx++;
                    }
                }
                http("POST", "/api/apps/upload/finish", new JSONObject().put("upload_id", id).toString());
                runOnUiThread(() -> { if (prog != null) prog.dismiss(); toast("已提交，等待管理员审核"); });
            } catch (Exception e) {
                runOnUiThread(() -> { if (prog != null) prog.dismiss(); toast("上传失败: " + e.getMessage()); });
            }
        });
    }

    static String safe(String s) { return s.replaceAll("[^\\w\\u4e00-\\u9fa5.-]", "_"); }

    static JSONObject http(String method, String path, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000); c.setReadTimeout(60000);
        if (!token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
        if (body != null) {
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setDoOutput(true);
            c.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = is == null ? "" : new String(readAll(is), StandardCharsets.UTF_8);
        if (code >= 400) throw new Exception(text.length() > 200 ? text.substring(0, 200) : text);
        return text.isEmpty() ? new JSONObject() : new JSONObject(text);
    }

    /** 返回非 null 表示成功；失败会抛异常 */
    static JSONObject httpMultipart(String path, String field, String filename, byte[] data, String... form) throws Exception {
        String boundary = "----ZD" + System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(15000); c.setReadTimeout(300000);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        if (!token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
        OutputStream os = c.getOutputStream();
        for (int i = 0; i + 1 < form.length; i += 2) {
            os.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + form[i] + "\"\r\n\r\n" + form[i + 1] + "\r\n").getBytes(StandardCharsets.UTF_8));
        }
        os.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + field + "\"; filename=\"" + safe(filename) + "\"\r\n" +
                "Content-Type: application/octet-stream\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        os.write(data);
        os.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        os.flush();
        int code = c.getResponseCode();
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = is == null ? "" : new String(readAll(is), StandardCharsets.UTF_8);
        if (code >= 400) throw new Exception(text.length() > 300 ? text.substring(0, 300) : text);
        return text.isEmpty() ? new JSONObject() : new JSONObject(text);
    }

    static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[8192]; int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        return o.toByteArray();
    }
}
